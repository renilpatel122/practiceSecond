package com.example.inventory_spec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorySpecApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorySpecApplication.class, args);
	}

}
